package com.elbeautenet.stockscan

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    companion object {
        private const val APP_URL = "https://elbeautenet-creator.github.io/stockscan/"
        private const val APP_HOST = "elbeautenet-creator.github.io"
        private val REQUIRED = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
    }

    private lateinit var webView: WebView
    private lateinit var gate: View
    private lateinit var gateButton: Button
    private lateinit var gateMessage: TextView
    private lateinit var errorView: View
    private lateinit var progress: ProgressBar

    private var appStarted = false
    private var hadError = false

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            refreshGate()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        gate = findViewById(R.id.permissionGate)
        gateButton = findViewById(R.id.gateButton)
        gateMessage = findViewById(R.id.gateMessage)
        errorView = findViewById(R.id.errorView)
        progress = findViewById(R.id.progress)

        findViewById<Button>(R.id.retryButton).setOnClickListener {
            errorView.visibility = View.GONE
            hadError = false
            webView.loadUrl(APP_URL)
        }

        gateButton.setOnClickListener {
            if (canAskAgain()) {
                permissionLauncher.launch(REQUIRED)
            } else {
                // تم الرفض نهائياً: الإعدادات هي الطريقة الوحيدة
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        .setData(Uri.fromParts("package", packageName, null))
                )
            }
        }

        setupWebView()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (appStarted && webView.canGoBack()) webView.goBack() else finish()
            }
        })

        if (!hasAllPermissions()) permissionLauncher.launch(REQUIRED)
        refreshGate()
    }

    override fun onResume() {
        super.onResume()
        // عند العودة من إعدادات النظام
        refreshGate()
    }

    private fun hasAllPermissions() = REQUIRED.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun canAskAgain() = REQUIRED.any {
        ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED &&
            (shouldShowRequestPermissionRationale(it) || !wasAskedBefore())
    }

    private fun wasAskedBefore(): Boolean {
        val prefs = getSharedPreferences("perm", MODE_PRIVATE)
        return prefs.getBoolean("asked", false)
    }

    /** الشرط الأساسي: لا يُحمَّل الموقع إلا بعد منح الكاميرا والميكروفون معاً. */
    private fun refreshGate() {
        if (hasAllPermissions()) {
            gate.visibility = View.GONE
            webView.visibility = View.VISIBLE
            if (!appStarted) {
                appStarted = true
                webView.loadUrl(APP_URL)
            }
        } else {
            getSharedPreferences("perm", MODE_PRIVATE).edit().putBoolean("asked", true).apply()
            if (appStarted) {
                webView.loadUrl("about:blank")
                appStarted = false
            }
            webView.visibility = View.GONE
            gate.visibility = View.VISIBLE
            if (canAskAgain()) {
                gateMessage.setText(R.string.gate_message)
                gateButton.setText(R.string.allow)
            } else {
                gateMessage.setText(R.string.gate_message_settings)
                gateButton.setText(R.string.open_settings)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }

        webView.webChromeClient = object : WebChromeClient() {
            // يمرّر طلب الكاميرا/الميكروفون من الصفحة بعد أن أصبحت أذونات النظام ممنوحة
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (request.origin.host == APP_HOST && hasAllPermissions()) {
                        request.grant(request.resources)
                    } else {
                        request.deny()
                    }
                }
            }

            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == APP_HOST) return false
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, request.url)) }
                return true
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                hadError = false
            }

            override fun onPageFinished(view: WebView, url: String?) {
                if (!hadError && url != "about:blank") errorView.visibility = View.GONE
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    hadError = true
                    errorView.visibility = View.VISIBLE
                }
            }
        }
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
